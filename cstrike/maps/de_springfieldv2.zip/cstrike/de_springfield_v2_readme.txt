de_springfield_v2 - bomb defusal map
Final version (I hope!) - 2/8/02
Mapped by Gameto 64
Big shouts to suicidal_monkey for tireless beta testing

Extract the zip file straight into your Half-Life
directory, over-writing any files it finds (just in
case there's some detritus left over from previous
versions).

All textures and sounds are either original, come
in the Half-Life pak file or were obtained from the 
public domain.

In this version all mapping and textures were 
created by me, the_mook. However, I cannot thank
Tugboatt027 enough for providing the inspiration
behind the layout, textures and some of the rooms.
I wish I could thank you personally, but I don't know 
your email adress or real name. For this reason I
have given Tugboatt027 joint authourship of the 
map.

Any ideas/suggestions/hatemail should be adressed
to steve_prior@hotmail.com, and if they are valid
they will be included in the next version.

Thankyous:
Tugboatt027 (obviously!)
Matt Groening
To my loyal band of beta-testers:
     clan[dg] - www.downgraded.barrysworld.net
     clan E*e - www.eeclan.com
Small_Sumo - for the krusty model
The skymap was modified from the dusk skymap. I don't
     know the author of this, but thank you anyway!
The modeller of Krusty's bottles
Ginseng Avenger for the Duff van (re-textured from one
     that appeared in Industry West)
Everyone on the Countermap forums for their continuous
     help during this and other projects.
Sam Mugford for easter-egg-based laughs
If I've forgotten anyone, email me and I'll rectify it
     in the next version

You can use any of the custom resources (sounds
and sky box), but credit would be greatly appreciated.
Email me for a copy of the wad file. Please don't
decompile or modify this map in any way without
OK'ing it with me first. Don't distribute in any form
other than over the Internet/BBS. You may NOT, under any
circumstances profit from the distribution of this
map - including, but not limited to, dispersal by
recordable media, or offering for download in 'members 
only' areas of internet sites. This file MUST accompany,
without modifications, the BSP file. The moral rights of 
the author are asserted at all times. 
(c) Stephen Prior, 2002

This map was mainly created while listening to The
Violent Femmes, and while under the influence of 
copious amounts of Stella Artois.

And an extra big thanks to the wifey, Elizabeth Walker,
for becoming a mapping widow and not complaining. Well,
not too much, anyway!